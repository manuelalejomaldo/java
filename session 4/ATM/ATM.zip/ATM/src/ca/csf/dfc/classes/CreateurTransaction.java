/**
 * 
 */
package ca.csf.dfc.classes;

/**
 * @author ManueLMaldonado
 *
 */
public interface CreateurTransaction {
	
	public Transaction Creertransaction (CompteCourant p_compte, Double p_montant);

}
