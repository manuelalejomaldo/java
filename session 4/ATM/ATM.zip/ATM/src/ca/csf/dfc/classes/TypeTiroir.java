/**
 * 
 */
package ca.csf.dfc.classes;

/**
 * @author ManueLMaldonado
 *
 */
public enum TypeTiroir {
	COM,
	SERIE,
	USB
}
