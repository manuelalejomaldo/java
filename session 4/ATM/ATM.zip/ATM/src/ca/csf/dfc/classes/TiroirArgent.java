/**
 * 
 */
package ca.csf.dfc.classes;

/**
 * @author ManueLMaldonado
 *
 */
public interface TiroirArgent {
	
	public void DistribuerArgent();
}
