package ca.csf.dfc.a2018pooexamen01.mediatheque;

import java.util.*;

/**
 * @author ManueLMaldonado
 *
 */
public class Mediatheque {
	
	private MediathequeRepository m_MediathequeRepository;
	
	public Mediatheque(MediathequeRepository p_MediathequeRepository) {
		this.m_MediathequeRepository = p_MediathequeRepository;
	}
}
