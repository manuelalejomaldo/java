package ca.csf.dfc.a2018pooexamen01.mediatheque;

/**
 * @author ManueLMaldonado
 *
 */
public enum TypeMedia {
	Livre,
	LivreBroche,
	LivrePoche,
	Numerique,
	NumeriqueUSB,
	CompactDisk
}
