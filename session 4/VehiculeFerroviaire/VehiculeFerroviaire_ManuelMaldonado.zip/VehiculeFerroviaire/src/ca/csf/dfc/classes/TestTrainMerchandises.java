/**
 * 
 */
package ca.csf.dfc.classes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author ManueLMaldonado
 *
 */
class TestTrainMerchandises {

	/**
	 * Test method for {@link ca.csf.dfc.classes.TrainMerchandises#TrainMerchandises()}.
	 */
	@Test
	void testTrainMerchandises() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link ca.csf.dfc.classes.TrainMerchandises#TrainMerchandises(int, int)}.
	 */
	@Test
	void testTrainMerchandisesIntInt() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link ca.csf.dfc.classes.TrainMerchandises#att()}.
	 */
	@Test
	void testAtt() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link ca.csf.dfc.classes.TrainMerchandises#detacher()}.
	 */
	@Test
	void testDetacher() {
		fail("Not yet implemented");
	}

}
