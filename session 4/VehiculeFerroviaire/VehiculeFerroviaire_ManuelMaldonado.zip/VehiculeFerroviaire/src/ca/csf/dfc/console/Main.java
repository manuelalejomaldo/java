package ca.csf.dfc.console;
import ca.csf.dfc.classes.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//D�finition d'un tableau de vehicules ferroviares
		VehiculeFerroviaire[] tab = new VehiculeFerroviaire[10];
		
		System.out.println("\n Remplir 10 trains : (1) pour grandeVitesse, (2) pour Merchandises, autre Voyageur \n");
		//choissir le type de train 
		for(VehiculeFerroviaire v : tab){
			System.out.println("\n Slectionez le type du train:");
			
			/*
			 * dans cette section je vous demande que type du train
			 * */
		}
		
		//notre tableau !
		for(VehiculeFerroviaire v : tab){
				System.out.println(v.toString()+"\n");
				
				
				/*
				 * dans cette section je motre par console le tableau
				 * */
		}
	}
}
