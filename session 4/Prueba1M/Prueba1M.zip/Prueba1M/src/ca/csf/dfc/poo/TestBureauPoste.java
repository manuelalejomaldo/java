package ca.csf.dfc.poo;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;

import javax.swing.ImageIcon;

import org.junit.Test;

public class TestBureauPoste {

	@SuppressWarnings("unchecked")
	@Test
	public <T> void testEnvoi() {
		
		
	
				
		
		
		
		
		
		
		
	}

	@Test
	public void testGetListmessage() {
		fail("Not yet implemented");
	}

}
