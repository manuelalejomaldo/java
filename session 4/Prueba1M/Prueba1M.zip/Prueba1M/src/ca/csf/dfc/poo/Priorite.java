package ca.csf.dfc.poo;

public enum Priorite {
	VeryLow, Low, Default, High, VeryHigh;

}
