/**
 * 
 */
package ca.csf.dfc.dessin;

/**
 * @author Coralie-Hong Brière
 *
 */
public enum FormeType {
	LIGNE,
	ELLIPSE,
	RECTANGLE
}
