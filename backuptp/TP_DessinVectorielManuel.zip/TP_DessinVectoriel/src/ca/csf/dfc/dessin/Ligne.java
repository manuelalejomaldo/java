package ca.csf.dfc.dessin;

public class Ligne extends Forme{
	public Ligne() {
		super();
		this.m_type = FormeType.LIGNE;
	}
}
