package ca.csf.dfc.dessin;

public class Rectangle extends Forme {
	public Rectangle() {
		super();
		this.m_type = FormeType.RECTANGLE;
	}
}
