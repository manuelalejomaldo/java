package ca.csf.dfc.dessin;

public class Ellipse extends Forme{
	public Ellipse() {
		super();
		this.m_type = FormeType.ELLIPSE;
	}
	
}
